import os
import random
random.seed(20000503)
for i in range(0,2):
	f = '3_' + str(i) + '.in'
	file_ = open(f,'w')
	file_.write('exp(x)')
	file_.write('\n')
	a = random.randint(1,10)
	b = random.randint(a+1,20)
	n = 1000
	file_.write(str(a) + '\n' + str(b) + '\n' + str(n))
	file_.close()


for i in range(2,5):
	f = '3_' + str(i) + '.in'
	file_ = open(f,'w')
	file_.write('x**2 + 1')
	file_.write('\n')
	a = random.randint(1,500)
	b = random.randint(a+1,1000)
	n = 10000
	file_.write(str(a) + '\n' + str(b) + '\n' + str(n))
	file_.close()

for i in range(5,7):
	f = '3_' + str(i) + '.in'
	file_ = open(f,'w')
	file_.write('abs(x**3) + 1')
	file_.write('\n')
	a = random.randint(1,500)
	b = random.randint(a+1,1000)
	n = 10000
	file_.write(str(a) + '\n' + str(b) + '\n' + str(n))
	file_.close()

for i in range(7,10):
	f = '3_' + str(i) + '.in'
	file_ = open(f,'w')
	file_.write('log(x) + 1')
	file_.write('\n')
	a = random.randint(1,500)
	b = random.randint(a+1,1000)
	n = 10000
	file_.write(str(a) + '\n' + str(b) + '\n' + str(n))
	file_.close()




for i in range(10):
	infile  = '3_' + str(i) + '.in'
	ansfile = '3_' + str(i) + '.ans'
	os.system('python 3.py < %s > %s'%(infile,ansfile))
