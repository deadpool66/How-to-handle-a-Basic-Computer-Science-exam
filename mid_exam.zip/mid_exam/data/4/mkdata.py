import os
import random
random.seed(998244353)
s = ['exp(x)','x**2','log(x**2+1)+1','x**3','x**5+3*x**2','x','abs(x)','abs(x)**0.5']
for i in range(10):
	f = '4_' + str(i) + '.in'
	file_ = open(f,'w')
	file_.write(s[random.randint(0,len(s)-1)])
	file_.write('\n')
	file_.write(s[random.randint(0,len(s)-1)])
	file_.write('\n')
	file_.write(s[random.randint(0,len(s)-1)])
	file_.write('\n')
	file_.write(str(random.randint(1,50)))
	file_.write('\n')
	file_.write(str(random.randint(1,50)))
	file_.close()

for i in range(10):
	infile  = '4_' + str(i) + '.in'
	ansfile = '4_' + str(i) + '.ans'
	os.system('python 4.py < %s > %s'%(infile,ansfile))
