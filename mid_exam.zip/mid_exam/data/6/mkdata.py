import os
import random
random.seed(998244353)
for i in range(0,20):
	f = '6_' + str(i) + '.in'
	file_ = open(f,'w')
	L = []
	for i in range(random.randint(1,50)):
		L.append([])
		for j in range(random.randint(1,50)):
			L[i].append(random.randint(-1000000,1000000))
	file_.write(str(L))
	file_.close()

for i in range(0,20):
	infile  = '6_' + str(i) + '.in'
	ansfile = '6_' + str(i) + '.ans'
	os.system('python 6.py < %s > %s'%(infile,ansfile))
