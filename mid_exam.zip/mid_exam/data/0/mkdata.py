import os
import random
random.seed(20000503)
for i in range(10):
	f = '0_' + str(i) + '.in'
	file_ = open(f,'w')
	file_.write(str(random.randint(1,50)))
	file_.close()

for i in range(10):
	infile  = '0_' + str(i) + '.in'
	ansfile = '0_' + str(i) + '.ans'
	os.system('python 0.py < %s > %s'%(infile,ansfile))
