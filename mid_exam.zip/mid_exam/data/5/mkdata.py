import os
import random
random.seed(998244353)
for i in range(10):
	f = '5_' + str(i) + '.in'
	file_ = open(f,'w')
	len1 = random.randint(1,500)
	len2 = random.randint(1,500)
	file_.write(str([random.randint(-500,500) for i in range(len1)]))
	file_.write('\n')
	file_.write(str([random.randint(-500,500) for i in range(len2)]))
	file_.close()

for i in range(10):
	infile  = '5_' + str(i) + '.in'
	ansfile = '5_' + str(i) + '.ans'
	os.system('python 5.py < %s > %s'%(infile,ansfile))
