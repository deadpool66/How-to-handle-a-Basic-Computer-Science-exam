import os
import random
random.seed(20000503)
'''
for i in range(10):
	f = '1_' + str(i) + '.in'
	file_ = open(f,'w')
	if i>=5:
		file_.write(str(random.randint(1,int(1e100))))
	else:
		file_.write(str(random.randint(1,eval('1e'+str(random.randint(1,100))))))
	file_.close()
'''
for i in range(10):
	infile  = '1_' + str(i) + '.in'
	ansfile = '1_' + str(i) + '.ans'
	os.system('python 1.py < %s > %s'%(infile,ansfile))
