import os
import random
random.seed(20000503)
for i in range(10):
	f = '2_' + str(i) + '.in'
	file_ = open(f,'w')
	if i%4==0:
		file_.write('exp(x)*x**10')
	elif i%4==1:
		file_.write('exp(x)*sin(x)')
	elif i%4==2:
		file_.write('log(x)*cos(x)*exp(x)')
	elif i%4==3:
		file_.write('x**10 + x**3*exp(x) + log(x) + 5')
	file_.write('\n')
	file_.write(str(random.randint(1,500)))
	file_.close()

for i in range(10):
	infile  = '2_' + str(i) + '.in'
	ansfile = '2_' + str(i) + '.ans'
	os.system('python 2.py < %s > %s'%(infile,ansfile))
