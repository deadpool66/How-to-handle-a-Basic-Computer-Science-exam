from math import*
def diff2(f,h = 1E-5):
	#please code below
	
	#do not change the code below

s = input()
f = lambda x:eval(s)
x = int(input())
print("%.6f"%diff2(f)(x))
