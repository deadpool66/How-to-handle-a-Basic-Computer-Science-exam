def bit_sqsum(n):
	#please code below
	
	#do not change the code below

x = int(input())
print(bit_sqsum(x))
