from math import *
def distance(f,g,h,t1,t2):
	#please code below
	
	#do not change the code below

s1 = input()
s2 = input()
s3 = input()
t1 = int(input())
t2 = int(input())
f = lambda x:eval(s1)
g = lambda x:eval(s2)
h = lambda x:eval(s3)

print("%.6f"%distance(f,g,h,t1,t2))
