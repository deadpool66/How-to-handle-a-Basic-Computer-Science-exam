def tensor(A,B):
	#please code below
	
	#do not change the code below

A = eval(input())
B = eval(input())
print(tensor(A,B))
