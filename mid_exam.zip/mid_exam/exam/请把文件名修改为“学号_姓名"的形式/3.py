from math import *
def Trapezoid(f,a,b,n):
	#please code below
	
	#do not change the code below

s = input()
a = int(input())
b = int(input())
n = int(input())

f = lambda x:eval(s)
print("%.6f"%Trapezoid(f,a,b,n))
