def flat_sort(L):
	#please code below
	
	#do not change the code below

L = eval(input())
print(flat_sort(L))
