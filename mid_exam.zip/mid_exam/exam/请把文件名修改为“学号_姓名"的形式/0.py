from math import *
def g(x):
	#please code below
	
	#do not change the code below

x = int(input())
print("%.6f"%g(x))
