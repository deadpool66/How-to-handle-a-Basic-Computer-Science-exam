def flat_sort(L):
	tmp = []
	for i in L:
		for j in i:
			tmp.append(j)
	return sorted(tmp)

L = eval(input())
print(flat_sort(L))
