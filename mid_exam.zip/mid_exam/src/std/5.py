def tensor(A,B):
	res = []
	n = len(A)
	m = len(B)
	for i in range(n):
		for j in range(m):
			res.append(A[i]*B[j])
	return res

A = eval(input())
B = eval(input())
print(tensor(A,B))
