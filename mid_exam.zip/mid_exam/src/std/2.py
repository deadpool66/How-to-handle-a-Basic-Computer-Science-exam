from math import*
def diff2(f,h = 1E-5):
	return lambda x:(f(x+h)+f(x-h)-2*f(x))/h**2

s = input()
f = lambda x:eval(s)
x = int(input())
print("%.6f"%diff2(f)(x))
