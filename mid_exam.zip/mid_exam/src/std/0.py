from math import *
def g(x):
    return cos(2*x)*sinh(3*x)
x = int(input())
print("%.6f"%g(x))
