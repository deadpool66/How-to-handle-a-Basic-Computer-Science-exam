def bit_sqsum(n):
	res = 0
	while(n):
		res += (n%10)**2
		n//=10
	return res

x = int(input())
print(bit_sqsum(x))
