from math import *
def Trapezoid(f,a,b,n):
	tmp = 0
	h = (b-a)/n
	tmp = sum([f(a+i*h) for i in range(1,n)])
	tmp *= 2
	res = (b-a) / (2*n) * (f(a) + tmp + f(a+n*h))
	return res

s = input()
a = int(input())
b = int(input())
n = int(input())

f = lambda x:eval(s)
print(Trapezoid(f,a,b,n))
