from math import *
def distance(f,g,h,t1,t2):
	x = [f(t1),g(t1),h(t1)]
	y = [f(t2),g(t2),h(t2)]
	return sqrt(sum([(x[i]-y[i])**2 for i in range(3)]))

s1 = input()
s2 = input()
s3 = input()
t1 = int(input())
t2 = int(input())
f = lambda x:eval(s1)
g = lambda x:eval(s2)
h = lambda x:eval(s3)

print(distance(f,g,h,t1,t2))
