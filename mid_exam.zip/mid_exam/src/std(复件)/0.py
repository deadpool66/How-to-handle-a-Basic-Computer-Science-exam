from math import cos,sinh
def g(x):
    return round(cos(2*x)*sinh(3*x),6)
x = int(input())
print('%.6f'%g(x))
