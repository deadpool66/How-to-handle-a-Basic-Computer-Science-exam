from math import*
def diff2(f,h = 1E-8):
	return lambda x:(f(x+h)+f(x-h)-2*f(x))/h**2

s = input()
f = lambda x:eval(s)
x = float(input())
print(diff2(f)(x))
