#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#           __   _,--="=--,_   __
#          /  \."    .-.    "./  \
#         /  ,/  _   : :   _  \/` \
#         \  `| /o\  :_:  /o\ |\__/
#          `-'| :="~` _ `~"=: |
#             \`     (_)     `/
#      .-"-.   \      |      /   .-"-.
# .---{     }--|  /,.-'-.,\  |--{     }---.
#  )  (_)_)_)  \_/`~-===-~`\_/  (_(_(_)  (
# (           Coding like a dog           )
#  )                                     (
# '---------------------------------------'


import os
import signal
import time
import threading
import pandas as pd

def copy_file(a, b):
    fa = open(a, "r")
    fb = open(b, "w")
    fb.write(fa.read())
    fa.close()
    fb.close()


def check_ignore_extra_space(file_a, file_b):
    str_a = open(file_a, "r").read()
    str_b = open(file_b, "r").read()
    if str_a == str_b:
        return 2, True
    list_a = str_a.split("\n")
    list_b = str_b.split("\n")
    while list_a and list_a[-1] == "":
        list_a.pop()
    while list_b and list_b[-1] == "":
        list_b.pop()
    if len(list_a) != len(list_b):
        return 0, False
    for i in range(len(list_a)):
        a = list_a[i].split()
        b = list_a[i].split()
        while a and a[-1] == "":
            a.pop()
        while b and b[-1] == "":
            b.pop()
        if a != b:
            return 0, False
    return 2, True
'''
def set_timeout(num, callback):
    def wrap(func):
        def handle(signum, frame):
            raise RuntimeError

        def to_do(*args, **kwargs):
            try:
                signal.signal(signal.SIGALRM, handle)
                signal.alarm(num)
                print('start alarm signal.')
                r = func(*args, **kwargs)
                print('close alarm signal.')
                signal.alarm(0)
                return r
            except RuntimeError as e:
                callback()
        return to_do
    return wrap

def after_timeout():
    print('Time limit exceeded!')
'''
class Checker:
    """
    Checker is a class to check the standard answer 
    and user's answer.
    """

    def __init__(
        self,
        problem_name,
        check_fn=check_ignore_extra_space,
        input_extension=".in",
        output_extension=".out",
        ans_extension=".ans",
        src_folder="src/",
        data_folder="data/",
        id_range=range(0, 20),
    ):
        """
        check_fn is the function that checks the answers.
        The default check_fn will igore the extra space
        at the end of each line.
        """
        self.problem_name = problem_name
        self.check_fn = check_fn

        self.input_extension = input_extension
        self.output_extension = output_extension
        self.ans_extension = ans_extension

        self.src_folder = src_folder
        self.data_folder = data_folder

        self.in_file = "tmp/" + problem_name + input_extension
        self.out_file = "tmp/" + problem_name + output_extension

        self.id_range = id_range

    def get_score(self, usr_name):
        #@set_timeout(1, after_timeout)
        score = []
        def runprog():
            os.system("python tmp/main.py < %s > %s" % (self.in_file, self.out_file))
        total_score = 0
        for self.problem_name in range(7):
            self.problem_name = str(self.problem_name)
            src = self.src_folder + usr_name + "/" + self.problem_name + ".py"
            copy_file(src, "tmp/main.py")
            for idx in self.id_range:
                input_file = (
                    self.data_folder + self.problem_name + '/' + self.problem_name + '_' + str(idx) + self.input_extension
                )
                std_ans_file = (
                    self.data_folder + self.problem_name + '/' + self.problem_name + '_' + str(idx) + self.ans_extension
                )
                copy_file(input_file, self.in_file)

                t = threading.Thread(target=runprog)
                t.setDaemon(True)
                t.start()
                t.join(3)      #调整每组数据测试时间

                cur_score, is_correct = self.check_fn(self.out_file, std_ans_file)
                if is_correct:
                    result = self.problem_name + "_" + str(idx) + " :Accepted" 
                    print(result)
                    score.append(result)
                else:
                    result = self.problem_name + "_" + str(idx) + " :Wrong Answer" 
                    print(result)
                    score.append(result)
                total_score += cur_score

        score.append('total_score = ' + str(total_score))
        file_ = self.src_folder + usr_name + '/' + 'score.txt'
        f = open(file_,'w')
        for res in score:
            f.write(res)
            f.write('\n')
        f.close()
        return total_score

def get_number(x):
    return int(filter(str.isdigit,str(x)))

def main():
    checker = Checker("pluse",id_range=range(10))
    #score = checker.get_score("std")
    
    path = "./src"
    files = os.listdir(path)
    files.sort()
    name = []
    sco = []
    for file_ in files:
        print(file_ + ':')
        name.append(file_)
        score = checker.get_score(file_)
        sco.append(score)
        print(score)
    output = pd.DataFrame({'Name':name,'score':sco})
    output.to_csv('all_score.csv',index=False)
if __name__ == "__main__":
    main()
